package Day4.assignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day4hwApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day4hwApplication.class, args);
	}

}
