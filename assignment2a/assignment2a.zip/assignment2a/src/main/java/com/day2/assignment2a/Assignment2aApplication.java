package com.day2.assignment2a;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Assignment2aApplication {

	public static void main(String[] args) {
		SpringApplication.run(Assignment2aApplication.class, args);
	}

}
