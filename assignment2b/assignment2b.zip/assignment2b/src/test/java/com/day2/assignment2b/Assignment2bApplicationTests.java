package com.day2.assignment2b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assignment2bApplicationTests {

	@Test
	void contextLoads() {
	}

}
